package co.com.saraitel.gestionsaraitel.negocio.negocio.reglas.impl.sede;

import java.util.UUID;

import co.com.saraitel.gestionsaraitel.negocio.negocio.reglas.Rule;
import co.com.saraitel.gestionsaraitel.transversal.catalogo.CatalogoMensajes;
import co.com.saraitel.gestionsaraitel.transversal.excepciones.GestionSaraitelNegocioExcepcion;
import co.com.saraitel.gestionsaraitel.transversal.utilitarios.UtilUUID;

public class AsegurarCiudadSedeValidaRule implements Rule<UUID> {

	private static final Rule<UUID> instancia = new AsegurarCiudadSedeValidaRule();

	private AsegurarCiudadSedeValidaRule() {
	}

	public static final Rule<UUID> obtenerInstancia() {
		return instancia;
	}

	@Override
	public void ejecutar(UUID... datos) {
		var idCiudad = UtilUUID.obtenerValorDefecto(datos[0]);

		validarObligatoriedad(idCiudad);
	}

	private void validarObligatoriedad(UUID dato) {
		if (dato.equals(UtilUUID.obtenerUUIDDefecto())) {
			var mensajeUsuario = CatalogoMensajes.SedeNegocioImpl.CIUDAD_SEDE_OBLIGATORIA;
			throw GestionSaraitelNegocioExcepcion.crear(mensajeUsuario);
		}
	}
}
